package Task4;
import java.util.Scanner;
public class Weekdays {
    void WeekDays (int index) throws ArrayIndexOutOfBoundsException{

String days[] = new String[7];

days[0] = "Sunday";

days[1] = "Monday";

days[2] = "Tuesday";

days[3] = "Wednesday";

days[4] = "Thursday";

days [5] = "Friday";

days[6] = "Saturday";

if (index < days.length) 
{

System.out.println("day name based on user input: "+days[index]);
	}

else {

System.out.println("index out of array please enter valid index!!!");

}
    }
public static void main(String[] args) {

System.out.println("Enter day position: ");

Scanner sc = new Scanner(System.in);

int num = sc.nextInt();

Weekdays days = new Weekdays();

days.WeekDays (num);
}
}

