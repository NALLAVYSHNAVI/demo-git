package Task4;
class AgeNotWithinRangeException extends Exception {
    public AgeNotWithinRangeException(String message) {
        super(message);
    }
}

class NameNotValidException extends Exception {
    public NameNotValidException(String message) {
        super(message);
    }
}
public class Student {
    private int rollNo;
    private String name;
    private int age;
    private String course;

    public Student(int rollNo, String name, int age, String course) throws AgeNotWithinRangeException, NameNotValidException {
        
        if (age < 15 || age > 21) {
            throw new AgeNotWithinRangeException("Age must be between 15 and 21.");
        }

        // Validate name
        if (!isValidName(name)) {
            throw new NameNotValidException("Name is not valid. It should not contain numbers or special symbols.");
        }

        this.rollNo = rollNo;
        this.name = name;
        this.age = age;
        this.course = course;
    }

    private boolean isValidName(String name) {
        return name.matches("[a-zA-Z]+");
    }
    public static void main(String[] args) {
        try {
            
            Student validStudent = new Student(1, "JohnDoe", 18, "Computer Science");
            System.out.println("Student created successfully.");

          Student invalidNameStudent = new Student(3, "Sai", 25, "Physics");
          System.out.println("Name is not valid. It should not contain numbers or special symbols.\");\r\n"
          		+ "      ");

        } catch (AgeNotWithinRangeException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (NameNotValidException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

